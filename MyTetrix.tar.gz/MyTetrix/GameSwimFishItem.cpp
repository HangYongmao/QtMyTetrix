#include "GameSwimFishItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameSwimFishItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameSwimFishItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：fishType表示鱼的类型，根据这个鱼的类型来确定每种鱼的初始的位置的纵坐标，横坐标是给的一个随机的值
*         xCoord表示是一个x轴的值，这个值是随机产生的，这样就可以让每条鱼都不是同步的
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameSwimFishItem::GameSwimFishItem(const QString &imageName, GameFishType fishType, int xCoord, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myFishType(fishType)
    ,myX_Coord(xCoord),myImageName(imageName),count(0)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timeoutSlot()));
    timer->start( FISHSWIM_TIME );
}



/***********************************************************************
* 函数名称： ~GameSwimFishItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameSwimFishItem::~GameSwimFishItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSwimFishItem::initPosAndImage(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    QImage *image ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        fishPixmap = QPixmap::fromImage( *image ) ;

        //一张大图包括10个小鱼图，所以计算宽度时要除以10
        perWidth = fishPixmap.width() / 10  ;
        perHeight = fishPixmap.height() ;
        //初始的时候为第一条小鱼
        this->setPixmap( getFishStatePixmap( FishOne ) );
        //这个Item不是要放到Scene中去的，而是作为子控件放进去的
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        //这个初始坐标，不是在Scene中的坐标，而是在父Item中的坐标
        if( namePointHash.contains( myImageName ) )
        {
            //根据鱼的种类和配置文件中读取的初始坐标来确定鱼的初始位置坐标
            firstPos = getFirstPosByFishType( myFishType, namePointHash.value( myImageName ) ) ;
        }
        //设置其坐标值
        this->setPos( firstPos );
    }
}


/**************************************************************************
* 函数名称： getFishStatePixmap
* 功能描述：  这个是通过每条鱼的不同的状态，从这fishPixmap一整张大图中
*           得到相应的状态的图片的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
inline QPixmap GameSwimFishItem::getFishStatePixmap(FishState state)
{
    Q_ASSERT( !fishPixmap.isNull() ) ;
    return fishPixmap.copy( state*perWidth,0,perWidth,perHeight );
}


/**************************************************************************
* 函数名称： getFirstPosByFishType
* 功能描述： 根据鱼的种类和配置文件中读取的初始坐标来确定鱼的初始位置坐标
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：因为只有第一条向左的鱼与第一条向右的与从配置文件中读到的纵坐标不要处理
*         其他则要加上相应的间隔
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
QPoint GameSwimFishItem::getFirstPosByFishType(GameFishType fishtype, const QPoint &posFormFile)
{
    //默认是配置文件中的值
    QPoint pos = posFormFile ;
    int yCoord = pos.y() ;
    //通过这个初始的x轴来调节使得几条鱼不是同一个位置出发
    pos.setX( myX_Coord );
    switch( fishtype )
    {
        case FirstLeft:
            break ;
        case FirstRight:
            break ;
        case SecondLeft:
            //第一条向右游动的鱼与第二条向右游动的与之间纵坐标相差190
            pos.setY( yCoord + 190 );
            break ;
        case SecondRight:
            //第一条向左游动的鱼与第二条向左游动的与之间纵坐标相差190
            pos.setY( yCoord + 190 );
            break ;
        case ThirdLeft:
            //第一条向右游动的鱼与第三条向右游动的与之间纵坐标相差380
            pos.setY( yCoord + 380 );
            break ;
        default:
               break ;
    }
    return pos ;
}


/***********************************************************************
* 函数名称： swimmingAdanceLittle()
* 功能描述： 这个函数控制小鱼向前游动一点
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：两个向两个不同方向的鱼分别前进点，向右的鱼向右前进一点，向左的鱼向左前进一点
*        要注意判断当向左移动的小鱼移动到最右边时回到最右边重新开始，
*        当向右移动的小鱼移动到最右边时回到最左边重新开始，要注意小鱼本身的宽度
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameSwimFishItem::swimmingAdanceLittle()
{
    int xCoord = firstPos.x() ;    //记录上次x轴的值
    //每次想不同的方向前进5个坐标点
    int left_X_Offset = xCoord + 2 ;   //向左移动的小鱼下一此出现的位置的x轴坐标
    int right_X_Offset = xCoord - 2 ;  //向右移动的小鱼下一此出现的位置的x轴坐标

    switch( myFishType )     //根据不同方向的鱼向不同方向前进
    {
        case FirstLeft:
        case SecondLeft:
        case ThirdLeft:
            if( left_X_Offset > SCENEWIDTH )
            {
                firstPos.setX( 0 - perWidth );
            }
            else
            {
                firstPos.setX( left_X_Offset );
            }
            break ;
        case FirstRight:
        case SecondRight:
            if( right_X_Offset < (  0 - perWidth ) )
            {
                firstPos.setX( SCENEWIDTH );
            }
            else
            {
                firstPos.setX( right_X_Offset );
            }
            break ;
        default:
            break ;
    }
    //设置其坐标值，这样每次都移动啦一点
    this->setPos( firstPos );
}


/***********************************************************************
* 函数名称： timeoutSlot()
* 功能描述： timeout()信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：这里不能这么用：
*    static int num = 0 ;
*    属于静态局部变量，每个对象都可以改变这个值，所以不能达到我们想要的效果，
*    所以单独申请一个局部变量来计数
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameSwimFishItem::timeoutSlot()
{
    //设置鱼的状态
    this->setPixmap( getFishStatePixmap( (FishState)count ) );
    //这个函数控制小鱼向前游动一点
    swimmingAdanceLittle() ;

    if( count == 9 )
    {
        count = 0 ;
    }
    else
    {
        count += 1 ;
    }
}
