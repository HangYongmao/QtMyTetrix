#ifndef GAMEBOMBITEM_H
#define GAMEBOMBITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>
#include <QTimer>

#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个是BombItem的图片更新的时间间隔，单位为毫秒
#define         BOMPIMAGE_UPDATETIME           60

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

/*
这个是一个爆炸特效的类，当有某一行达到满行时，在消除某行前，显示这个爆炸特效
所谓爆炸特效也就是由7张图片组成的，通过快速的切换，达到想要的效果
*/
class GameBombItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    GameBombItem( QGraphicsItem *parent=0 );
    ~GameBombItem();


    //这个是初始化BombItem的图片的函数,因为坐标是根据满行位置的坐标来确定的
    void initBombItemImage( const NameAndImageHash &nameImagehash ) ;

private:

    /************************爆炸特效所用到的7张图片***********************/
    QPixmap bombPixmap1 ;
    QPixmap bombPixmap2 ;
    QPixmap bombPixmap3 ;
    QPixmap bombPixmap4 ;
    QPixmap bombPixmap5 ;
    QPixmap bombPixmap6 ;
    QPixmap bombPixmap7 ;

    QTimer *timer ;           //这是一个计时器，用于更新图片

    int count ;               //一个计数器，用来计数的，因为7张图片，要切换，默认为0

    int pixHeight ;           //因为这7张图片都是一样的大小所以用一个变量来统计高度

private slots:
    void timeoutSlot() ;      //timeout()信号的槽函数

    void showBombEffectSlot( int pos ) ;     //这个是发送显示爆炸特效槽函数
};

#endif // GAMEBOMBITEM_H
