#include "GameAreaItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameAreaItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameAreaItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameAreaItem::GameAreaItem(int levelNum, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),nowLevelNum(levelNum)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );
}



/***********************************************************************
* 函数名称： ~GameAreaItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameAreaItem::~GameAreaItem()
{
    //DEBUGP( "~GameAreaItem" ) ;
    delete board ;
    delete bombItem ;
}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::setGameScene(GameGraphicsScene *gameScene, const NameAndImageHash &nameImagehash)
{
    //这里之所以用一个m_Scene来接收游戏场景，这样可以很方便对下一块Item操作
    m_Scene = gameScene ;
    //连接一些对方块进行移动的信号与槽函数
    connect(gameScene,SIGNAL(leftKeyDownSignal()),this,SLOT(leftKeyDownSlot()));
    connect(gameScene,SIGNAL(rightKeyDownSignal()),this,SLOT(rightKeyDownSlot()));
    connect(gameScene,SIGNAL(upKeyDownSignal()),this,SLOT(upKeyDownSlot()));
    connect(gameScene,SIGNAL(downKeyDownSignal()),this,SLOT(downKeyDownSlot()));
    connect(gameScene,SIGNAL(spaceKeyDownSignal()),this,SLOT(spaceKeyDownSlot()));
    //连接从场景转发过来的重新开始游戏的信号与槽函数
    connect(gameScene,SIGNAL(restartButtonClickedSignal()),
            this,SLOT(gameRestartSlot())) ;
    //连接从场景中转发过来的游戏暂停信号
    connect(gameScene,SIGNAL(pauseKeyDownSignal()),this,SLOT(pauseKeyDownSlot()));
    //连接从场景中转发过来的游戏被停用时的发送的信号
    connect(gameScene,SIGNAL(gameDeactivateSignal()),this,SLOT(gameDeactivateSlot()));

    //初始化表示游戏区域的滑块下落的的板
    initTerixBoard(nameImagehash);
    //初始化这个是表示下一个方块的Item
    initNextPieceItem();
    //添加爆炸特效的Item
    addGameBombItem( nameImagehash ) ;
}

/**************************************************************************
* 函数名称： removeNextPieceItem
* 功能描述： 这个是留出的一个删除下一块的Item的接口
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::removeNextPieceItem()
{
    //DEBUGP( "removeNextPieceItem" ) ;
    if( nextPieceItem != NULL )
    {
        m_Scene->removeItem( nextPieceItem );
        delete nextPieceItem ;
        nextPieceItem = NULL ;
    }
    //其实析构函数里面会把board指针给delete掉的，这样写确保更加安全
    if( board != NULL )
    {
        delete board ;
        board = NULL ;
    }

}
/**************************************************************************
* 函数名称： initTerixBoard
* 功能描述： 初始化表示游戏区域的滑块下落的的板
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::initTerixBoard(const NameAndImageHash &nameImagehash)
{
    board = new TerixBoard( nowLevelNum,nameImagehash ) ;
    connect(board,SIGNAL(updateNextPiecePixmapSignal()),
            this,SLOT(updateNextPiecePixmapSlot()));
    connect(board,SIGNAL(updateGameAreaPixmapSignal()),
            this,SLOT(updateGameAreaPixmapSlot()));
    //连接一些中转信号
    connect(board,SIGNAL(updateSpeedNumSignal(int)),
            this,SIGNAL(updateSpeedNumSignal(int))) ;
    connect(board,SIGNAL(updateNumRowsRemovedSignal(int)),
            this,SIGNAL(updateNumRowsRemovedSignal(int)));
    connect(board,SIGNAL(updateScoreNumSignal(int)),
            this,SIGNAL(updateScoreNumSignal(int))) ;
    //中转游戏结束的信号
    connect(board,SIGNAL(gameOverSignal()),this,SIGNAL(gameOverSignal())) ;
    //中转这个是满行时产生爆炸声音的信号到场景中去
    connect(board,SIGNAL(crushAudioSoundSignal()),m_Scene,SIGNAL(crushAudioSoundSignal())) ;
    //中转这个是这个是当滑块落到最低点时撞击的声音的信号到场景中去
    connect(board,SIGNAL(fellAudioSoundSignal()),m_Scene,SIGNAL(fellAudioSoundSignal()));

    QPixmap gameAreaPixmap = board->getGameAreaPixmap();
    //设置游戏区域的图片
    this->setPixmap( gameAreaPixmap );
}


/**************************************************************************
* 函数名称： initNextPieceItem
* 功能描述： 初始化这个是表示下一个方块的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过传进来的游戏场景指针变量，对下一块的Item作为单独的
*        Item放入到场景中第四层去
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::initNextPieceItem()
{
    nextPieceItem = new QGraphicsPixmapItem() ;
    QPixmap nextPiecePixmap = board->getNextPiecePixmap() ;
    //设置下一块方块的图片
    nextPieceItem->setPixmap( nextPiecePixmap );
    m_Scene->addItem( nextPieceItem );
    //下一块的Item是作为第四层加到场景中去的
    nextPieceItem->setZValue( 4.0 );
    //这个是设置坐标，因为这个不能从配置文件中读取，只能这么写死
    nextPieceItem->setPos( 50,245 );

}

/**************************************************************************
* 函数名称： addGameBombItem
* 功能描述： 添加爆炸特效的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::addGameBombItem(const NameAndImageHash &nameImagehash)
{
    //作为游戏区域的子Item来添加
    bombItem = new GameBombItem( this ) ;
    //连接爆炸特效显示的信号与槽函数
    connect(board,SIGNAL(showBombEffectSignal(int)),bombItem,SLOT(showBombEffectSlot(int)));
    bombItem->initBombItemImage( nameImagehash );
    //默认情况是隐藏起来的，因为只有当要产生爆炸特效的时候才显示
    bombItem->hide();
}
/**************************************************************************
* 函数名称： updateNextPiecePixmapSlot
* 功能描述： 这个是更新显示下一块方块的图片的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::updateNextPiecePixmapSlot()
{
    QPixmap nextPiecePixmap = board->getNextPiecePixmap() ;
    //设置下一块方块的图片
    nextPieceItem->setPixmap( nextPiecePixmap );
}

/**************************************************************************
* 函数名称： updateGameAreaPixmapSlot
* 功能描述： 这个是更新游戏区域的图片的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::updateGameAreaPixmapSlot()
{
    QPixmap gameAreaPixmap = board->getGameAreaPixmap();
    //设置游戏区域的图片
    this->setPixmap( gameAreaPixmap );
}



/**************************************************************************
* 函数名称： updateNextPiecePixmapSlot
* 功能描述： 向左移动一列
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::leftKeyDownSlot()
{
    //如果游戏结束或者游戏暂停，则屏蔽按键动作
    if( !board->getGamePauseStateFun() && !board->getGameGameOverStateFun() )
    {
        //DEBUGP( "leftKeyDownSlot" ) ;
        board->moveToLeftFun();
    }
}

/**************************************************************************
* 函数名称： rightKeyDownSlot
* 功能描述： 向右移动一列
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::rightKeyDownSlot()
{
    //如果游戏结束或者游戏暂停，则屏蔽按键动作
    if( !board->getGamePauseStateFun() && !board->getGameGameOverStateFun() )
    {
        //DEBUGP( "rightKeyDownSlot" ) ;
        board->moveToRightFun();
    }
}

/**************************************************************************
* 函数名称： upKeyDownSlot
* 功能描述： 变形操作，每次逆时针旋转90度
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::upKeyDownSlot()
{
    //如果游戏结束或者游戏暂停，则屏蔽按键动作
    if( !board->getGamePauseStateFun() && !board->getGameGameOverStateFun() )
    {
        //DEBUGP( "upKeyDownSlot" ) ;
        board->rotateFun() ;
    }
}

/**************************************************************************
* 函数名称： downKeyDownSlot
* 功能描述： 向下移动一行
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::downKeyDownSlot()
{
    //如果游戏结束或者游戏暂停，则屏蔽按键动作
    if( !board->getGamePauseStateFun() && !board->getGameGameOverStateFun() )
    {
        //DEBUGP( "downKeyDownSlot" ) ;
        board->oneLineDownFun();
    }
}

/**************************************************************************
* 函数名称： spaceKeyDownSlot
* 功能描述： 直接扔到最底部
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::spaceKeyDownSlot()
{
    //如果游戏结束或者游戏暂停，则屏蔽按键动作
    if( !board->getGamePauseStateFun() && !board->getGameGameOverStateFun() )
    {
        //DEBUGP( "spaceKeyDownSlot" ) ;
        board->dropDownFun();
    }
}


/**************************************************************************
* 函数名称： pauseKeyDownSlot
* 功能描述： 按下p键的暂停游戏的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::pauseKeyDownSlot()
{
    board->pauseKeyDownFun();
}
/**************************************************************************
* 函数名称： gameRestartSlot
* 功能描述： 这个是游戏重新开始的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::gameRestartSlot()
{
    //DEBUGP( "gameRestartSlot" ) ;
    if( board != NULL )
    {
        board->restartGame();
    }
}


/**************************************************************************
* 函数名称： gameDeactivateSlot
* 功能描述： 这个是当游戏被停用时的发送的信号
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameAreaItem::gameDeactivateSlot()
{
    board->gameDeactivateFun();
}
