#ifndef GAMEINTRODUCTIONITEM_H
#define GAMEINTRODUCTIONITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>

#include "globaldefines.h"
#include "GameGraphicsScene.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

/*
这个类是游戏介绍的一个类，单独做为一个类，当鼠标点击到其上时，其应该消失
*/
class GameIntroductionItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /*
    通过这个当前箭头所对应的序号的值
    比如说
    0---->开始游戏
    1---->游戏介绍
    。。。。。。
    在NumAndPointerHash表中查找相应的Item的指针的值
    */
    //在这里是用户点击的时候发送这个信号出去，返回到游戏的首页去
    void backToSecondLay( int index ) ;

public:

    GameIntroductionItem(const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameIntroductionItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    void setGameScene( GameGraphicsScene *gameScene,const NameAndImageHash &hash ) ;


private:

    QString myImageName ;        //用来承载构造函数的imageName参数的
    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QPixmap introPixmap ;        //图片

protected:
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;
};

#endif // GAMEINTRODUCTIONITEM_H
