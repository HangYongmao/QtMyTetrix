#include "GameGameOverItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameGameOverItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameGameOverItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameGameOverItem::GameGameOverItem(const QString &imageName, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myImageName(imageName)
{

    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );

}



/***********************************************************************
* 函数名称： ~GameGameOverItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameGameOverItem::~GameGameOverItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景，这里由于显示时铺满整个场景，故不要初始坐标，所以只要啦两个参数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameOverItem::setGameScene(GameGraphicsScene *gameScene,
                                       const NameAndImageHash &nameImagehash,
                                       const NameAndPointHash &namePointHash)
{
    QImage *image ;
    m_Scene = gameScene ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        gameOverPixmap = QPixmap::fromImage( *image ) ;
        //这个是直接设置图片，因为只有一张图片，不需更多的处理
        this->setPixmap( gameOverPixmap );

        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        if( namePointHash.contains( myImageName ) )
        {
            this->setPos( namePointHash.value( myImageName ) );
        }

        //添加退出按钮的Item
        addGameButtonItem( nameImagehash,namePointHash ) ;
    }
}

/**************************************************************************
* 函数名称： addGameButtonItem
* 功能描述：添加退出按钮的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameOverItem::addGameButtonItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    //这个按钮作为游戏结束对话框的子Item来显示
    restartButton = new GameButtonItem( MAINWIN_RESTART ,this ) ;
    //把重新开始按钮的点击信号转到场景信号
    connect(restartButton,SIGNAL(buttonClick()),m_Scene,SIGNAL(restartButtonClickedSignal()));
    restartButton->initPosAndImage( nameImagehash,namePointHash );
}
