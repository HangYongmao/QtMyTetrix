#include "GameNumItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameNumItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameNumItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameNumItem::GameNumItem(const QString &imageName, GameNumType type, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),numType(type)
    ,myImageName(imageName)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );

}



/***********************************************************************
* 函数名称： ~GameNumItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameNumItem::~GameNumItem()
{

}

/***********************************************************************
* 函数名称： setNumPixmap()
* 功能描述： 这个是对外留出的一个接口，通过这个接口来显示不同的数字的图片，一定是整形
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：数字之所以用字符串形式，因为有时要显示“09”这样显示
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameNumItem::setNumPixmap(QString numString)
{
    int count = numString.count() ;    //得到数字的位数
    if( count == 1 )    //如果是一个1位数
    {
        //可以直接显示这个1位数
        QChar ch = numString.at(0) ;
        int num = ch.digitValue() ;    //把数字字符转换为整形
        this->setPixmap( getDigitalPixmap( num ) );
    }
    else   //如果不只1位数
    {
        //初始化一个画布的大小，几位数就初始化对应的多大
        QPixmap pixmap( perWidth*count ,perHeight ) ;
        pixmap.fill(Qt::transparent);      //填充图片为透明色

        QPainter painter( &pixmap );
        //这个是绘制非1位数字的图片时，用到的绘制函数
        drawNumStringPixmap( painter,numString) ;
        //可以直接显示这个1位数
        this->setPixmap( pixmap );
    }
}
/**************************************************************************
* 函数名称： initPosAndImage
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameNumItem::initPosAndImage(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{

    QImage *image ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        numPixmap = QPixmap::fromImage( *image ) ;

        //一张大图包括10个数字，所以计算宽度时要除以10
        perWidth = numPixmap.width() / 10  ;
        perHeight = numPixmap.height() ;

        //这个Item不是要放到Scene中去的，而是作为子控件放进去的
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        //这个初始坐标，不是在Scene中的坐标，而是在父Item中的坐标
        if( namePointHash.contains( myImageName ) )
        {
            //根据数字的种类和配置文件中读取的初始坐标来确定数字的初始位置坐标
            firstPos = getFirstPosByNumType( numType,namePointHash.value( myImageName ) );
        }
        this->setPos( firstPos );
    }
}


/***********************************************************************
* 函数名称： getFirstPosByNumType()
* 功能描述： 根据数字的种类和配置文件中读取的初始坐标来确定数字的初始位置坐标
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：表示速度的数字的坐标是从配置文件中得到的
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
QPoint GameNumItem::getFirstPosByNumType(GameNumType numtype, const QPoint &posFormFile)
{
    //默认是配置文件中的值
    QPoint pos = posFormFile ;
    int xCoord = pos.x() ;
    int yCoord = pos.y() ;
    switch( numtype )
    {
        case SpeedNum:
            break ;
        case RowNum:
            //表示行数的数字与表示速度的数字间隔100
            pos.setX( xCoord + 35 );      //x轴的值做微调
            pos.setY( yCoord + 105 );
            break ;
        case ScoreNum:
            //表示表示分数的数字与表示速度的数字间隔200
            pos.setY( yCoord + 200 );
        default:
               break ;
    }
    return pos ;
}


/***********************************************************************
* 函数名称： getDigitalPixmap
* 功能描述： 从这numPixmap一整张大图中得到相应的数字的的图片的函数
*        在这里只是得到的0到9的每个数字对应的图片
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
inline QPixmap GameNumItem::getDigitalPixmap(int num)
{
    Q_ASSERT( !numPixmap.isNull() ) ;
    return numPixmap.copy( num*perWidth,0,perWidth,perHeight );
}


/***********************************************************************
* 函数名称： drawNumStringPixmap
* 功能描述： 这个是绘制非1位数字的图片时，用到的绘制函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameNumItem::drawNumStringPixmap(QPainter &painter, QString numString)
{
    int count = numString.count() ;    //得到数字的位数
    for( int i=0;i<count;i++ )
    {
        QChar ch = numString.at(i) ;
        int num = ch.digitValue() ;    //把数字字符转换为整形
        painter.setPen(Qt::NoPen);     //设置无画笔
        painter.drawPixmap( perWidth*i,0,getDigitalPixmap(num) );
    }

}
