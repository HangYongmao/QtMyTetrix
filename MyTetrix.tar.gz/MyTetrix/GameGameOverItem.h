#ifndef GAMEGAMEOVERITEM_H
#define GAMEGAMEOVERITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>

#include "globaldefines.h"
#include "GameGraphicsScene.h"
#include "GameButtonItem.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class GameGameOverItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:

public:
    GameGameOverItem( const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameGameOverItem();

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

private:

    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QString myImageName ;        //用来承载构造函数的imageName参数的

    QPixmap gameOverPixmap ;             //游戏结束图片

    GameButtonItem *restartButton ;     //重新开始按钮
    //添加退出按钮的Item
    void addGameButtonItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash );
};

#endif // GAMEGAMEOVERITEM_H
