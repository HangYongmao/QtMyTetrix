#ifndef GAMESPINKEYITEM_H
#define GAMESPINKEYITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QVariant>


#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个表示Key图片可以滑动的轨道的长度
#define   TRACKLENGTH        100

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个是游戏设置上表示音量的spin上的的滑块的类
*/
class GameSpinKeyItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    GameSpinKeyItem(const QString &imageName,int volume = 0,
                    bool type = true ,QGraphicsItem *parent=0) ;
    ~GameSpinKeyItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;
    //这个是对外留出的接口，用于得到当前坐标转换为声音的值
    int getNowVolume() ;
private:

    int myVolume ;               //这个是表示初始的音量的值,这个值要转换为相应的坐标值
    /*
    这个表示类型，true表示是音乐的音量，false表示的是音效的音量
    */
    bool myType ;
    QString myImageName ;        //用来承载构造函数的imageName参数的
    QPixmap keyPixmap ;       //图片
    //这个值是从配置文件中读出的
    QPoint firstPos ;           //这个表示key图标的初始坐标值

    //根据音量的值，计算出spin图标坐标的值
    inline QPoint getNowPointByVolume( int volume ) ;
    //根据当前坐标的值，计算出对应音量的值
    inline int getVolumeByNowPoint( QPoint nowPoint ) ;
protected:

    QVariant itemChange ( GraphicsItemChange change, const QVariant & value ) ;
};

#endif // GAMESPINKEYITEM_H
