#ifndef GAMEOPTIONITEM_H
#define GAMEOPTIONITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QSettings>


#include "GameSpinKeyItem.h"
#include "FullScreenCheckItem.h"
#include "GameButtonItem.h"
#include "GameGraphicsScene.h"

#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这是一个表示游戏选项的类，表示游戏背景声与音效的声音的设置
*/
class GameOptionItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /*
    通过这个当前箭头所对应的序号的值
    比如说
    0---->开始游戏
    1---->游戏介绍
    。。。。。。
    在NumAndPointerHash表中查找相应的Item的指针的值
    */
    //在这里是用户点击的时候发送这个信号出去，返回到游戏的首页去
    void backToSecondLay( int index ) ;

    /*************这个发送的改变游戏音乐与音效音量大小的信号*************/
    void changeVolumeSignal( int musicVolume , int audioVolume ) ;

public:
    GameOptionItem(const QString &imageName ,int musicVolume,int audioVolume ,
                   bool fullScreen,QGraphicsItem *parent=0) ;
    ~GameOptionItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;
    //设在配置文件
    void setConfigureFile( QSettings *configIni ) ;

private:

    QString myImageName ;        //用来承载构造函数的imageName参数的
    int myMusicVolume ;          //用来承载构造函数的musicVolume参数的
    int myAudioVolume ;          //用来承载构造函数的audioVolume参数的
    bool myFullScreen ;          //用来承载构造函数的fullScreen参数的
    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量

    QPixmap optionPixmap ;       //图片

    GameSpinKeyItem *musicKeyItem ;   //调节音乐音量大小的Item
    GameSpinKeyItem *audioKeyItem ;   //调节音效音量大小的Item

    FullScreenCheckItem *checkItem ;    //选择全屏的Item

    GameButtonItem *okButton ;          //确定按钮的Item
    GameButtonItem *cancelButton ;      //取消按钮的Item

    //初始化两个调节音量大小的Item
   void initSpinKeyItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

    QSettings *m_ConfigIni ;          //用来承载配置文件的指针的变量
    //把音量的值写到配置文件中去
    inline void setVolumeValueToFile( QString groupname ,QString A_valueString,int volume ) ;
    //把是否全屏的值写到配置文件中去
    inline void setFullScreenValueToFile( QString groupname ,QString A_valueString,bool fullscreen ) ;

private slots:
    //这个是点击ok按钮的槽函数
    void clickOnOkButtonSlot() ;
    //这个是点击cancel按钮的槽函数
    void clickOnCancelButtonSlot() ;

protected:
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;

};

#endif // GAMEOPTIONITEM_H
