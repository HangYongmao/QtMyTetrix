#ifndef GameButtonItem_H
#define GameButtonItem_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>


#include "globaldefines.h"
#include "GameGraphicsScene.h"
/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个类是定义的一个Button的类，这些Button有一个特点就是当鼠标移动到上面时其图标会改变，
单击该Button时图标也会改变。所以在这里抽象一个类出来，让类似的这样的按钮都可以这样处理，
通过每个图片的名字来进行区别，那个鱼的图片与数字的图片不是在这里处理的，这里只处理那种5个
按钮状态图片
*/
class GameButtonItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /*
    当鼠标悬浮在5个modewin的Button上时，就发送这个信号
    */
    void mouseOnMe() ;
    /*
    这个是的一个单击的信号，当单击时，或者按下回车时，会触发该信号
    */
    void buttonClick() ;

public:
    GameButtonItem(const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameButtonItem() ;

    /****************************************************************************/
    //这个是当Item加到Scene中去
    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

    /****************************************************************************/
    //这个是单作为某个Item的子Item使用时的接口，因为不需要加到Scene中
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;
    /****************************************************************************/

private:
    /*
    这个是定义的Button的状态的一个枚举类型
    Normal：表示的是按钮正常情况下
    Actived：表示的是当鼠标在按钮上时
    Pressed：表示当鼠标单击在按钮上时
    */
    enum ButtonState { Normal = 0 , Actived , Pressed } ;

    QString myImageName ;            //用来承载构造函数的imageName参数的
    GameGraphicsScene *m_Scene ;       //用来承载游戏场景的变量
    int pixWidth ;                  //这个是记录图片的宽与高的两个变量
    int pixHeight ;                 //注意这里记录的是一个状态的图片的宽与高，不是整张大图的宽与高
    QPixmap buttonPixmap ;          //这个是一个完整的大图
    /*
    这个是通过Button的不同的状态，从这buttonPixmap一整张大图中
    得到相应的状态的图片的函数
    */
    inline QPixmap getButtonStatePixmap( ButtonState state ) ;

    /*
    这个用来标识是否鼠标左键被按下，默认的情况下是false
    */
    bool isPressed ;
protected:
    //这是重载的四个鼠标事件，通过这些事件来控制Button各个状态的图片显示
    void hoverEnterEvent ( QGraphicsSceneHoverEvent * event ) ;
    void hoverLeaveEvent ( QGraphicsSceneHoverEvent * event ) ;
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;

};
#endif // GameButtonItem_H
