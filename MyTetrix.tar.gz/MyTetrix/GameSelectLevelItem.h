#ifndef GAMESELECTLEVELITEM_H
#define GAMESELECTLEVELITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QTimeLine>
#include <QGraphicsSceneMouseEvent>
#include <QList>
#include <QRect>
#include <QSize>
#include <QLineF>


#include "GameButtonItem.h"
#include "globaldefines.h"


/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个是选择关卡时，默认的一个超过的宏定义
#define   NOT_SUCH_LEVEL       11

//这个是定义的两个动态效果的时间片段，单位为毫秒
#define    START_TIMELINE       600
#define    END_TTIMELINE        600
/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这个是自己定义的一个QPoint列表
typedef   QList< QPoint >      PointList ;

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class GameSelectLevelItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

signals:
    //这个是发送当前关卡数的信号
    void nowLevelNumSignal( int levelNum ) ;
    //这个是发送的endTimeLine结束的信号
    void endTimeLineOverSignal() ;
public:
    GameSelectLevelItem(const QString &imageName,QGraphicsItem *parent=0);
    ~GameSelectLevelItem();

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;
    //把这个函数作为共有函数，通过外面来激活动画
    void beginStartTimeLine() ;       //开始startTimeLine效果
private:
    QString myImageName ;        //用来承载构造函数的imageName参数的
    int currentLevelNum ;        //表示当前的关卡数，默认为1
    QPixmap levelPixmap ;        //图片
    QPixmap choosePixmap ;       //表示选中的对勾的图片

    QPoint startPos ;            //这个表示关卡选择Item的初始坐标值,动画的起点坐标
    QPoint endPos ;              //这个表示关卡选择Item的初始坐标值,动画的终点坐标

    GameButtonItem *okButton ;   //确定按钮Item

    QSize choPixSize ;            //对勾的图片的Size

    QGraphicsPixmapItem *chooseItem ;    //这个是表示对勾的Item
    QPoint chooseFirstPos ;          //这个是表示对勾的初始坐标值
    PointList pointList ;            //用于存储QPoint的列表
    void initPointList() ;           //初始化用于存储QPoint的列表
    //根据单击事件所在的位置来确定所选的关卡
    int getLevelNumbyNowPoint( const QPoint &nowPoint ) ;
    //这个是初始化对勾的Item
    void initChoosePixmapItem( const NameAndImageHash &nameImagehash,
                               const NameAndPointHash &namePointHash ) ;
    //添加确定按钮的Item
    void addOkButtonItem(const NameAndImageHash &nameImagehash,
                         const NameAndPointHash &namePointHash ) ;

    QTimeLine *startTimeLine ;        //这个是开始时一个动画的时间轴
    QTimeLine *endTimeLine ;          //这个是结束时一个动画的时间轴

    void initAllTimeLine() ;          //初始化两个QTimeLine的函数

    void beginEndTimeLine() ;         //开始startTimeLine效果

private slots:
    void showStartTimeLineAnimation( int frame );       //startTimeLine动画效果
    void startTimeLineFinished() ;             //startTimeLine的动画时间结束

    void showEndTimeLineAnimation( int frame );       //endTimeLine动画效果
    void endTimeLineFinished() ;             //startTimeLine的动画时间结束

    void clickOnOkButton() ;         //点击按钮的槽函数
protected:
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;
};

#endif // GAMESELECTLEVELITEM_H
