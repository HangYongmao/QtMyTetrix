#ifndef GLOBALDEFINES_H
#define GLOBALDEFINES_H

#include <QString>
#include <QHash>
#include <QImage>
#include <QPoint>
#include <QDebug>

/*
这个文件里面是定义的一些全局宏定义或在数据类型
*/

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//定义的光标文件的路经
#define    GLOBAL_CURSOR_IMAGE     "./cursor.png"

//定义的配置文件的路经
#define    CONFIGUREPATH           "./configure.ini"

//这个是定义的场景scene的宽度，因为默认情况下场景scene是无限大的
//这里用宏定义写死的话，后面要是全屏扩展不好弄
#define    SCENEWIDTH          800
#define    SCENEHEIGHT         600

/****************************************************************************
    下面是定义的一些配置文件中的组名，在这里统一定义方便
    注意如果配置文件中的名字改变，这个位置的定义也要做相应的改变
    这个下面的宏定义是定义的每组的图片数目的A值，所谓A值就是等号左边的值
    如
    LogoCount=2中A值为LogoCount，之后可以读到其数目值2
****************************************************************************/
#define    GROUPNAME_LOGO              "Logo"
#define    LOGO_COUNT                  "LogoCount"

#define    GROUPNAME_MODEWIN           "ModeWin"
#define    MODEWIN_COUNT               "ModeWinCount"

#define    GROUPNAME_DIANWOWIN         "DianWoWin"
#define    DIANWOWIN_COUNT             "DianWoWinCount"

#define    GROUPNAME_OPTIONWID         "OptionWin"
#define    OPTIONWID_COUNT             "OptionWinCount"

#define    GROUPNAME_BOX               "Box"
#define    BOX_COUNT                   "BoxCount"

#define    GROUPNAME_BACKWIN           "BackWin"
#define    BACKWIN_COUNT               "BackWinCount"


#define    GROUPNAME_BOMBWIN           "BombWin"
#define    BOMBWIN_COUNT               "BombWinCount"

#define    GROUPNAME_MAINWIN           "MainWin"
#define    MAINWIN_COUNT               "MainWinCount"

//这些是定义的要处理的图片的组
#define    GROUPNAME_MUSTMODIFY           "MustModify"
#define    MUSTMODIFY_COUNT               "MustModifyCount"

//这个是表示设置的组，用来记录用户设置的一些选项
#define    GROUPNAME_SETTINGS             "Settings"
//#define    SETTINGS_COUNT                 "SettingsCount"

//这个是定义的部分控件在场景中初始化坐标的组
#define    GROUPNAME_COORDINATE           "CoordiNate"
#define    COORDINATE_COUNT               "CoordiNateCount"


//这个是定义的游戏音乐文件与音效文件的路经的组
#define    GROUPNAME_SOUND                "Sound"
//#define    SOUND_COUNT                    "SoundCount"


/***************************************************************************
    下面是一些宏定义，对应的是配置文件中的A值
    因为配置文件的形式
    [组名]
    A=B
    注意这样写之后配置文件中的A值改变，这个相应的宏定义的值也就要做相应的改变
    值所以要这么写，就是为啦让读取配置文件的函数通用，因为想只通过一个组名就可
    以遍历这个组下面的所有的条例，而不需要一条一条的去读取，
    通过这些宏定义来记录A值，以后可以很方便的引用某一个图片文件。
****************************************************************************/
/*
注意在配置文件中的分隔符与这里的宏定义中的分隔符不同，不这样写的会不能匹配，可能是因为
linux系统是以/符号作为分隔符的吧，所以从配置文件中读进去之后，其改变啦其分隔符，这里要
慎重
*/
//Logo组
#define   LOGO_1                     "Logo/logo1"
#define   LOGO_2                     "Logo/logo2"

//DianWoWin组
#define   DIANWOWIN_BUTTON           "DianWoWin/button"
#define   DIANWOWIN_WIN              "DianWoWin/dianwowin"
#define   DIANWOWIN_OK               "DianWoWin/ok"
#define   DIANWOWIN_CANCEL           "DianWoWin/cancel"


//ModeWin组
#define   MODEWIN_ARROW              "ModeWin/arrow"
#define   MODEWIN_BACK               "ModeWin/back"
#define   MODEWIN_BEGINWIM           "ModeWin/beginwin"
#define   MODEWIN_EXIT               "ModeWin/exit"
#define   MODEWIN_HELP               "ModeWin/help"
#define   MODEWIN_HIGHSCORE          "ModeWin/highscore"
#define   MODEWIN_HIGHWIN            "ModeWin/highwin"
#define   MODEWIN_INSTRUCTION        "ModeWin/instruction"
#define   MODEWIN_MOREGAME           "ModeWin/moregame"
#define   MODEWIN_OPTION             "ModeWin/option"
#define   MODEWIN_START              "ModeWin/start"

//OptionWin组
#define   OPTIONWIN_SETTING          "OptionWin/setting"
#define   OPTIONWIN_CHECKBOX1        "OptionWin/checkbox1"
#define   OPTIONWIN_CHECKBOX2        "OptionWin/checkbox2"
#define   OPTIONWIN_CHOOSE           "OptionWin/choose"
#define   OPTIONWIN_CANCEL           "OptionWin/cancel"
#define   OPTIONWIN_KEY              "OptionWin/key"
#define   OPTIONWIN_OK               "OptionWin/ok"


//Box组
#define   BOX_BOX1                   "Box/box1"
#define   BOX_BOX2                   "Box/box2"
#define   BOX_BOX3                   "Box/box3"
#define   BOX_BOX4                   "Box/box4"
#define   BOX_BOX5                   "Box/box5"
#define   BOX_BOX6                   "Box/box6"
#define   BOX_BOX7                   "Box/box7"
#define   BOX_NUMB                   "Box/numb"


//BackWin组
#define   BACKWIN_BACKWIN             "BackWin/backwin"
#define   BACKWIN_CANCEL              "BackWin/cancel"
#define   BACKWIN_OK                  "BackWin/ok"


//BombWin组
#define   BOMBWIN_BOMB1               "BombWin/bomb1"
#define   BOMBWIN_BOMB2               "BombWin/bomb2"
#define   BOMBWIN_BOMB3               "BombWin/bomb3"
#define   BOMBWIN_BOMB4               "BombWin/bomb4"
#define   BOMBWIN_BOMB5               "BombWin/bomb5"
#define   BOMBWIN_BOMB6               "BombWin/bomb6"
#define   BOMBWIN_BOMB7               "BombWin/bomb7"

//MainWin组
#define   MAINWIN_BACKGROUND           "MainWin/background"
#define   MAINWIN_CHECKBOX1            "MainWin/checkbox1"
#define   MAINWIN_CHECKBOX2            "MainWin/checkbox2"
#define   MAINWIN_CHOOSE               "MainWin/choose"
#define   MAINWIN_EXIT                 "MainWin/edit"
#define   MAINWIN_ENTNAME              "MainWin/entname"
#define   MAINWIN_FISHLEFT             "MainWin/fishleft"
#define   MAINWIN_FISHRIGHT            "MainWin/fishright"
#define   MAINWIN_GAMEOVER             "MainWin/gameover"
#define   MAINWIN_MENU                 "MainWin/menu"
#define   MAINWIN_RESTART              "MainWin/restart"
#define   MAINWIN_SELECTLEVEL          "MainWin/selectlevel"
#define   MAINWIN_SUMIT                "MainWin/submit"
#define   MAINWIN_OK                   "MainWin/ok"
#define   MAINWIN_ENTERNAME            "MainWin/entername"
#define   MAINWIN_PAUSE                "MainWin/pause"
#define   MAINWIN_FOREGROUND           "MainWin/foreground"


/*
这个是用于记录读取用户对音乐与音效音量大小的调节，以及是否全屏的调节
*/
#define   SETTINGS_AUDIO               "Settings/audio"
#define   SETTINGS_MUSIC               "Settings/music"
#define   SETTINGS_FULLSCREEN          "Settings/FullScreen"


/*
这个是用于记录游戏相关的音乐文件的路经的，音效与音乐相关特效文件
*/
#define   SOUND_MUSIC                  "Sound/music"
#define   SOUND_CRUSHAUDIO             "Sound/crushaudio"
#define   SOUND_FELLAUDIO              "Sound/fellaudio"
#define   SOUND_POPOAUDIO              "Sound/popoaudio"

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/
/*
这个是定义的一个调试的宏定义用于调试，之后整个工程完成可以关闭这个开关
*/
#ifdef __DEBUG__

#define   DEBUGP(ARGS)   {                                      \
    qDebug() << "##File :" << __FILE__<< "##Line :" <<__LINE__      \
     << "##Function :" <<__FUNCTION__ << "##Argument :" << ARGS  << endl ;    \
}

#else

#define   DEBUGP(ARGS)

#endif

//这个是定义的一个安全锁，避免进入死循环的
#define    SECURE_LOCK(ARGS)   {                                 \
    if( ARGS > 5 )                                               \
    {                                                            \
        DEBUGP( "Open the Secure Lock Avoid Dead Loop !" )       \
        break ;                                                  \
    }                                                            \
    ARGS += 1 ;                                                  \
}

/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这个是自己定义的一个数据类型，表示图片名字与图片指针的一个对应关系
typedef  QHash< QString,QImage * >  NameAndImageHash ;

//这个是自己定义的一个数据类型，表示图片名字与图片坐标一个对应关系
typedef  QHash< QString,QPoint >    NameAndPointHash ;


//这个是自己定义的一个数据类型，一个整形与指针的一个对应的hash表
/*
这个是因为当第三层出现时，用户按下Esc键，要回到第二层游戏首页，
所以在这里用这个hash表来记录
*/
typedef  QHash< int, void * >       NumAndPointerHash ;

#endif // GLOBALDEFINES_H
