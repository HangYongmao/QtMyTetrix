#include "GameBombItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameBombItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameBombItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameBombItem::GameBombItem( QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),count(0)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timeoutSlot()));


}



/***********************************************************************
* 函数名称： ~GameBombItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameBombItem::~GameBombItem()
{

}


/**************************************************************************
* 函数名称： initBombItemImage
* 功能描述： 这个是初始化BombItem的图片的函数,因为坐标是根据满行位置的坐标来确定的
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameBombItem::initBombItemImage(const NameAndImageHash &nameImagehash)
{
    if( nameImagehash.contains( BOMBWIN_BOMB1 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB1 ) ;
        bombPixmap1 = QPixmap::fromImage( *image ) ;
        pixHeight = bombPixmap1.height() ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB2 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB2 ) ;
        bombPixmap2 = QPixmap::fromImage( *image ) ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB3 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB3 ) ;
        bombPixmap3 = QPixmap::fromImage( *image ) ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB4 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB4 ) ;
        bombPixmap4 = QPixmap::fromImage( *image ) ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB5 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB5 ) ;
        bombPixmap5 = QPixmap::fromImage( *image ) ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB6 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB6 ) ;
        bombPixmap6 = QPixmap::fromImage( *image ) ;
    }
    if( nameImagehash.contains( BOMBWIN_BOMB7 ) )
    {
        QImage *image = nameImagehash.value( BOMBWIN_BOMB7 ) ;
        bombPixmap7 = QPixmap::fromImage( *image ) ;
    }
}


/***********************************************************************
* 函数名称： timeoutSlot()
* 功能描述： timeout()信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameBombItem::timeoutSlot()
{
    //因为7张图片切换，切换完成就退出
    if( !count )
    {
        this->setPixmap( bombPixmap1 );
    }
    else if( count == 1 )
    {
        this->setPixmap( bombPixmap2 );
    }
    else if( count == 2 )
    {
        this->setPixmap( bombPixmap3 );
    }
    else if( count == 3 )
    {
        this->setPixmap( bombPixmap4 );
    }
    else if( count == 4 )
    {
        this->setPixmap( bombPixmap5 );
    }
    else if( count == 5 )
    {
        this->setPixmap( bombPixmap6 );
    }
    else if( count == 6 )
    {
        this->setPixmap( bombPixmap7 );
        //整个动作完成在这里结束更新计时器，并且隐藏该Item
        timer->stop();
        this->hide();
        count = 0 ;    //清零进行下次循环显示爆炸特效
    }
    count += 1 ;       //计数器加1，以便下次再切换到另一个图片
}



/***********************************************************************
* 函数名称： timeoutSlot()
* 功能描述： timeout()信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameBombItem::showBombEffectSlot(int pos)
{
    //首先显示这个Item
    this->show();
    //设置爆炸特效Item的坐标
    //通过信号传过来的pos的y轴的值不能直接用，因为没有考虑到图片的高度，
    //所以在这里先减去图片的高度
    //因为图片比游戏区域略宽，所有这里的x轴做啦一点调整
    this->setPos( -2, ( pos - pixHeight ) );
    //这个是开始爆炸特效的计时器
    timer->start( BOMPIMAGE_UPDATETIME );

}
