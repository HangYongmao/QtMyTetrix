#ifndef TETRIXWIDGET_H
#define TETRIXWIDGET_H


#include <QDesktopWidget>
#include <QApplication>
#include <QWidget>
#include <QGraphicsView>
#include <QSettings>
#include <QStringList>
#include <QImage>
#include <QPoint>
#include <QKeyEvent>


#include "GameGraphicsScene.h"
#include "GameBackGroundItem.h"
#include "GameLogoImageItem.h"
#include "GameButtonItem.h"
#include "GameArrowItem.h"
#include "GameMovBackGrouItem.h"
#include "GameIntroductionItem.h"
#include "GameOptionItem.h"
#include "GameHighWinItem.h"

#include "GameGameSound.h"

#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class TetrixWidget : public QWidget
{
    Q_OBJECT
signals:
    //发送信号给ArrowItem，改变其坐标到坐标索引的index
    void moveArrowat( int index ) ;

    //这个是遮蔽箭头item上面的箭头的信号
    //这个信号放在这个类里是因为，按钮弹出的Item会通过按Esc来返回，这样就不能再发信号还原
    //其状态
    void coverOnArowItemSignal( bool state ) ;

    /**********************这个是当游戏被停用时的发送的信号********************/
    //这个是当游戏被停用时的发送的信号
    //就是当鼠标点击电脑桌面其他位置时，就是我们平常所说的整个游戏软件失去焦点时。发送这个信号
    void gameDeactivateSignal() ;
public:
    TetrixWidget(QWidget *parent=0) ;
    ~TetrixWidget() ;

private:
    QGraphicsView *gameView ;
    GameGraphicsScene *gameScene ;

    void setTetrixWigAttribute() ;          //设置TetrixWidget类的属性

    void initGameSceneAndView() ;           //初始化游戏的场景与视图


    QSettings *configIni ;        //这个是用于读取配置文件指针
    //这是定义的一个表，用来存储图片名字与图片的指针
    //这个作为一个大的容器，所以图片都放在里面。便于之后用
    NameAndImageHash  nameImageHash ;

    //根据组名及每组对应的图片数目的A值来读取配置文件，并且加载图片文件。
    void initAndLoadImage( QString groupname, QString A_valueString ) ;

    void loadAllImageFile() ;      //加载所有的图片

    //这个坐标ponit用于取图片上某个坐标点的色素作为透明色，默认为QPoint( 0,0 )
    QImage *getTransImage( QImage *image , QPoint ponit = QPoint( 0,0 ) ) ;

    /*
    这个是处理所有的粉红色背景的图片，使只编程透明色背景
    */
    void dealPinkBackGroundImage( QString groupname, QString A_valueString ) ;

    /*
    这个是因为当第三层出现时，用户按下Esc键，要回到第二层游戏首页，
    所以在这里用这个hash表来记录
    */
    NumAndPointerHash numPointer ;
    /*
    这个是用来记录当前在第二层上面的Item，通过这个序号在NumAndPointerHash
    中查找Item对应的指针，默认为-1
    */
    int nowIndex ;
    /*
    这里是因为，这个设置的图片太小，要把下面的开始与退出按钮给隐藏掉，
    不然用户移动鼠标会误点到
    */
    void setSomeItemVisible( bool visible ) ;
    //从配置文件中读出所要的音量的值
    inline int getVolumeValueFromFile( QString groupname ,QString A_valueString ) ;
    //从配置文件中读取是否要设置全屏
    inline bool getFullScreenValueFromFile( QString groupname ,QString A_valueString ) ;


    /****************************最底层的Item******************************/
    GameLogoImageItem *logoImageItem ;
    void addGameLogoImageItem( ) ;           //添加GameLogoImageItem到场景去

    GameBackGroundItem *backGroundItem ;
    //这是定义的一个表，用来存储图片名字与图片的坐标
    //部分图片的坐标不需要写在配置文件，因为其默认坐标一直都是（0，0）
    NameAndPointHash namePointHash ;
    //根据组名及每组对应的图片数目的A值来读取配置文件，并且记录到namePointHash中去。
    void initNameAndPointHash( QString groupname ,QString A_valueString ) ;

    /****************************第二层的Item******************************/
    GameButtonItem *dianwoButton ;            //点我的广告按钮
    GameButtonItem *moregameButton ;          //更多的游戏按钮
    GameButtonItem *startgameButton ;         //开始游戏按钮
    GameButtonItem *instrgameButton ;         //游戏介绍按钮
    GameButtonItem *gameoptionButton ;        //游戏选项按钮
    GameButtonItem *gamehihgscButton ;        //游戏排行榜按钮
    GameButtonItem *exitgameButton ;          //退出游戏按钮
    GameArrowItem  *arrowItem ;               //箭头Item
    /*
    添加所有的第二层的Item，通过一个接口把所有的第二层的Item全部放进来，方便管理
    */
    void addAllSecondLayerItem() ;
    //分开进行添加这样不至于让一个函数变的很长
    void addDianWoButton() ;       //添加点我按钮
    void addMoreGameButton() ;     //添加更多的游戏按钮
    void addStartGameButton() ;    //添加开始游戏按钮
    void addInstrGameButton() ;    //添加游戏介绍按钮
    void addGameOptionButton() ;   //添加游戏选项按钮
    void addGameHihgscButton() ;   //添加游戏排行榜按钮
    void addExitGameButton() ;     //添加退出游戏按钮
    void addArrowItem() ;          //添加箭头Item
    /****************************第三层的Item******************************/

    GameMovBackGrouItem *movBacGrouItem ;    //动态背景图片
    GameIntroductionItem *introduItem ;      //游戏介绍Item
    GameOptionItem *optionItem ;             //游戏选项Item
    GameHighWinItem *highWinItem ;           //游戏排行榜Item

    /**************************游戏的背景音乐与音效的处理*************************/
    GameGameSound *gameSound ;      //游戏的背景音乐与音效
    void initGameGameSound() ;      //初始化游戏的背景音乐与音效

private slots:
    void addGameBackGroundItem( ) ;         //添加GameBackGroundItem到场景去

    void mouseOnStartgameButton( ) ;        //光标在开始游戏按钮
    void mouseOnInstrgameButton( ) ;        //光标在游戏介绍按钮
    void mouseOnGameOptionButton( ) ;       //光标在游戏选项按钮
    void mouseOnGameHihgscButton( ) ;       //光标在游戏排行榜按钮
    void mouseOnExitgameButton( ) ;         //光标在退出游戏按钮

    void clickOnStartgameButton( ) ;        //单击开始游戏按钮
    void clickOnInstrgameButton( ) ;        //单击游戏介绍按钮
    void clickOnGameOptionButton( ) ;       //单击游戏选项按钮
    void clickOnGameHihgscButton( ) ;       //单击游戏排行榜按钮
    void clickOnExitgameButton( ) ;         //单击退出游戏按钮

    /*
    这个是根据当前箭头序号来确定进入到哪个Item的槽函数
    */
    void clickOnButton( int index ) ;

    /*
    用户按Esc键返回到第二层，返回游戏首页的信号的槽函数
    */
    void backToSecondLaySlot( int index ) ;
    //这个是前景Item的退回到游戏首页的按钮的槽函数
    void backToGameHomeSlot() ;
protected:
    //事件过滤器
    bool eventFilter ( QObject * watched, QEvent * event ) ;
    void	resizeEvent ( QResizeEvent * event );
};

#endif // TETRIXWIDGET_H
