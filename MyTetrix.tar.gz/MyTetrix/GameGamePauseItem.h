#ifndef GAMEGAMEPAUSEITEM_H
#define GAMEGAMEPAUSEITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>

#include "globaldefines.h"
#include "GameGraphicsScene.h"
#include "GameButtonItem.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class GameGamePauseItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:

public:
    GameGamePauseItem( const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameGamePauseItem();

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

private:

    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QString myImageName ;        //用来承载构造函数的imageName参数的

    QPixmap gamePausePixmap ;             //游戏暂停图片

};

#endif // GAMEGAMEPAUSEITEM_H
