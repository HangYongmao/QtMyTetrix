#ifndef GAMEAREAITEM_H
#define GAMEAREAITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>


#include "TetrixBoard.h"
#include "GameGraphicsScene.h"
#include "GameBombItem.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class GameAreaItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /**************这个是更新速度，消除的总行数的，以及得分的信号的中转信号************/
    //传给GameMovBackGrouItem类中去处理
    //这个是更新消除的速度的信号
    void updateSpeedNumSignal( int speedNum );
    //这个是更新消除的总行数的信号
    void updateNumRowsRemovedSignal( int rowNum ) ;
    //这个是更新消除的用户分数的信号
    void updateScoreNumSignal( int score ) ;
    //这个是发送的游戏结束的信号
    void gameOverSignal() ;

public:
    GameAreaItem( int levelNum , QGraphicsItem *parent=0 );
    ~GameAreaItem();
    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    void setGameScene( GameGraphicsScene *gameScene,const NameAndImageHash &nameImagehash) ;
    //这个是留出的一个删除下一块的Item的接口
    void removeNextPieceItem() ;
private:
    int nowLevelNum ;           //表示当前的level的数字
    GameGraphicsScene *m_Scene ;   //用来承载游戏场景的变量
    TerixBoard *board ;        //表示游戏区域的滑块下落的的板
    //初始化表示游戏区域的滑块下落的的板
    void initTerixBoard( const NameAndImageHash &nameImagehash );
    //这个是表示下一个方块的Item
    QGraphicsPixmapItem *nextPieceItem ;
    //初始化这个是表示下一个方块的Item
    void initNextPieceItem() ;

    /*******************这个是添加的BombItem的区域*******************/
    GameBombItem *bombItem ;             //爆炸特效的Item
    //添加爆炸特效的Item
    void addGameBombItem( const NameAndImageHash &nameImagehash ) ;
private slots:
    //这个是更新显示下一块方块的图片的槽函数
    void updateNextPiecePixmapSlot() ;
    //这个是更新游戏区域的图片的槽函数
    void updateGameAreaPixmapSlot() ;

    /*******************这是定义的一些对方块进行移动变形操作的槽函数*******************/
    void leftKeyDownSlot() ;
    void rightKeyDownSlot() ;
    void upKeyDownSlot() ;
    void downKeyDownSlot() ;
    void spaceKeyDownSlot() ;
    //在GameMovBackGrouItem类中还有一个暂停游戏的槽函数
    void pauseKeyDownSlot() ;              //按下p键的暂停游戏的槽函数

    //这个是游戏重新开始的槽函数
    //在GameMovBackGrouItem类中还有一个重启的槽函数
    void gameRestartSlot() ;

    /**********************这个是当游戏被停用时的发送的信号********************/
    //这个是当游戏被停用时的发送的信号
    //就是当鼠标点击电脑桌面其他位置时，就是我们平常所说的整个游戏软件失去焦点时。发送这个信号
    //在GameMovBackGrouItem类中还有一个同样的槽函数
    void gameDeactivateSlot() ;

};
#endif // GAMEAREAITEM_H
