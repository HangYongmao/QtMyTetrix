#ifndef GAMELOGOIMAGEITEM_H
#define GAMELOGOIMAGEITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>
#include <QTimeLine>


#include "globaldefines.h"
#include "GameGraphicsScene.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个是定义的logo图片动画效果的时间片段,单位为毫秒
#define    LOGOIMAGE_TIMELINE          1200

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个游戏背景是整个游戏软件的最底层，整个软件共分为6层，可以参看目录下的游戏设计的整体分层思想
这一层，用来显示两个Logo图片，和用来显示背景图片的GameBackGroundItem在同一层
*/
class GameLogoImageItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    //这个是当两个logo渐显的效果完成之后，发出信号要添加背景层图片的信号
    void addGameBackGroundItem() ;
public:
    GameLogoImageItem( QGraphicsItem *parent=0) ;
    ~GameLogoImageItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    void setGameScene( GameGraphicsScene *gameScene,const NameAndImageHash &hash ) ;


private:

    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QPixmap logoPixmap1  ;      //两个logo图片
    QPixmap logoPixmap2  ;
    QImage resultImage ;        //这个是一个渐变的效果的图片，用于在此基础上绘图

    QTimeLine *timeLine ;

    void timeLineStart( ) ;                //开始显示logo渐变的动画效果
    void getFadeOutImage( int alpha ) ;        //得到一个渐显效果的图片
private slots:
    void showAnimationtoMove( int frame );       //动画效果
    void timeLineFinished() ;             //firsttimeLine的动画时间结束
};

#endif // GAMELOGOIMAGEITEM_H
