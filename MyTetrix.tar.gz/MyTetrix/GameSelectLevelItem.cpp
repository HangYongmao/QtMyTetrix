#include "GameSelectLevelItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameSelectLevelItem实现--公有部分                     *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameSelectLevelItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameSelectLevelItem::GameSelectLevelItem(const QString &imageName, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent)
    ,myImageName(imageName),currentLevelNum(1)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );
    //初始化两个QTimeLine的函数
    initAllTimeLine() ;
    //开始startTimeLine效果
    beginStartTimeLine() ;
}



/***********************************************************************
* 函数名称： ~GameSelectLevelItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameSelectLevelItem::~GameSelectLevelItem()
{

}

/**************************************************************************
* 函数名称： initPosAndImage
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::initPosAndImage(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{

    QImage *image ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        levelPixmap = QPixmap::fromImage( *image ) ;
        //图片的高度，用于计算动画的终点坐标值
        int pixHeight = levelPixmap.height() ;

        this->setPixmap( levelPixmap );
        //这个Item不是要放到Scene中去的，而是作为子控件放进去的
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        //这个初始坐标，不是在Scene中的坐标，而是在父Item中的坐标
        if( namePointHash.contains( myImageName ) )
        {
            //这是记录从配置文件中读取的坐标的值
            startPos = namePointHash.value( myImageName ) ;
            //设置终点与起点的x轴坐标相同，要轴坐标刚好为0减去图片高度
            //这样刚好使得图片看不到
            endPos.setX( startPos.x() );
            endPos.setY( 0 - pixHeight );
            //根据数字的种类和配置文件中读取的初始坐标来确定数字的初始位置坐标
            //因为要达到逐渐下降的动画效果所以这里先是没有设置这个坐标的
            //this->setPos( firstPos );
        }
        //这个是初始化对勾的Item
        initChoosePixmapItem( nameImagehash,namePointHash ) ;

        //添加确定按钮的Item
        addOkButtonItem( nameImagehash,namePointHash) ;
    }
}


/**************************************************************************
* 函数名称： beginStartTimeLine
* 功能描述： 开始startTimeLine效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::beginStartTimeLine()
{
    if (startTimeLine->state() == QTimeLine::NotRunning)
    {
        startTimeLine->setFrameRange(0, 100);
        startTimeLine->setCurveShape(QTimeLine::LinearCurve);
        startTimeLine->setUpdateInterval(30);     //每20毫秒改变一次
        startTimeLine->start();
    }
}

/***********************************************************************
* 函数名称： initChoosePixmapItem()
* 功能描述： 这个是初始化对勾的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameSelectLevelItem::initChoosePixmapItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( MAINWIN_CHOOSE ) )
    {
        //这里是这么写死啦没有进行判断
        QImage *image = nameImagehash.value( MAINWIN_CHOOSE ) ;
        choosePixmap = QPixmap::fromImage( *image ) ;

        choPixSize = choosePixmap.size() ;

        //这个对勾Item作为关卡选择的子控件
        chooseItem = new QGraphicsPixmapItem( this ) ;
        chooseItem->setPixmap( choosePixmap );
        //这个Item不是要放到Scene中去的，而是作为子控件放进去的
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        //这个初始坐标，不是在Scene中的坐标，而是在父Item中的坐标
        if( namePointHash.contains( myImageName ) )
        {
            //这是记录从配置文件中读取的坐标的值
            chooseFirstPos = namePointHash.value( MAINWIN_CHOOSE ) ;
            //根据数字的种类和配置文件中读取的初始坐标来确定数字的初始位置坐标
            chooseItem->setPos( chooseFirstPos ) ;
        }
        initPointList();    //初始化用于存储QPoint的列表
    }
}


/***********************************************************************
* 函数名称： initPointList()
* 功能描述： 初始化用于存储QPoint的列表
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameSelectLevelItem::initPointList()
{
    //由于图片做的不标准，之间的间隔不是很统一，所以这里把这些坐标写死
    //写到一个坐标列表中，用于切换
    pointList.append( QPoint( 133,115 ) );
    pointList.append( QPoint( 133,160 ) );
    pointList.append( QPoint( 133,203 ) );
    pointList.append( QPoint( 135,244 ) );
    pointList.append( QPoint( 135,284 ) );
    pointList.append( QPoint( 248,115 ) );
    pointList.append( QPoint( 248,160 ) );
    pointList.append( QPoint( 250,202 ) );
    pointList.append( QPoint( 249,243 ) );
    pointList.append( QPoint( 249,284 ) );
}
/***********************************************************************
* 函数名称： addOkButtonItem()
* 功能描述： 添加确定按钮的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameSelectLevelItem::addOkButtonItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    okButton =new GameButtonItem( MAINWIN_OK,this ) ;
    connect(okButton,SIGNAL(buttonClick()),this,SLOT(clickOnOkButton())) ;
    okButton->initPosAndImage( nameImagehash,namePointHash) ;
}


/**************************************************************************
* 函数名称： initAllTimeLine
* 功能描述： 初始化两个QTimeLine的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::initAllTimeLine()
{
    startTimeLine = new QTimeLine( START_TIMELINE,this ) ;
    connect( startTimeLine,SIGNAL(frameChanged(int)),this,SLOT(showStartTimeLineAnimation(int)));
    connect(startTimeLine,SIGNAL(finished()),this,SLOT(startTimeLineFinished()));


    endTimeLine = new QTimeLine( END_TTIMELINE,this ) ;
    connect( endTimeLine,SIGNAL(frameChanged(int)),this,SLOT(showEndTimeLineAnimation(int)));
    connect(endTimeLine,SIGNAL(finished()),this,SLOT(endTimeLineFinished()));

}


/**************************************************************************
* 函数名称： getLevelNumbyNowPoint
* 功能描述： 根据单击事件所在的位置来确定所选的关卡
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：返回值为1到11，当返回1到10之间的数字（包含1和10）时表示对应的关数，
*         当返回11时，表示鼠标单击在其他位置没有要选择的关卡
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
int GameSelectLevelItem::getLevelNumbyNowPoint(const QPoint &nowPoint)
{
    //因为是从第一关开始匹配，所以默认值为1
    int num = 1 ;
    foreach( QPoint point,pointList )
    {
        QRect rect( point,choPixSize ) ;
        //如果这个坐标点再这个矩形框内
        if( rect.contains( nowPoint ) )
        {
            break ;
        }
        num += 1 ;
    }
    return num ;
}



/**************************************************************************
* 函数名称： beginEndTimeLine
* 功能描述： 开始endTimeLine效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::beginEndTimeLine()
{
    if (endTimeLine->state() == QTimeLine::NotRunning)
    {
        endTimeLine->setFrameRange(0, 100);
        endTimeLine->setCurveShape(QTimeLine::LinearCurve);
        endTimeLine->setUpdateInterval(30);     //每20毫秒改变一次
        endTimeLine->start();
    }
}
/**************************************************************************
* 函数名称： showStartTimeLineAnimation
* 功能描述： startTimeLine动画效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::showStartTimeLineAnimation(int frame)
{
    QLineF lineToMove(endPos,startPos) ;
    int length = lineToMove.length()  ;
    //qDebug() << "the length is : " << length << endl ;
    QLineF line ;
    line.setP1( endPos );
    line.setLength( (((qreal)length)/100)*frame );
    line.setAngle( lineToMove.angle() );
    this->setPos( line.p2() );
}


/**************************************************************************
* 函数名称： startTimeLineFinished
* 功能描述： startTimeLine的动画时间结束
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::startTimeLineFinished()
{

}


/**************************************************************************
* 函数名称： showEndTimeLineAnimation
* 功能描述： endTimeLine动画效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::showEndTimeLineAnimation(int frame)
{
    QLineF lineToMove(startPos,endPos) ;
    int length = lineToMove.length()  ;
    //qDebug() << "the length is : " << length << endl ;
    QLineF line ;
    line.setP1( startPos );
    line.setLength( (((qreal)length)/100)*frame );
    line.setAngle( lineToMove.angle() );
    this->setPos( line.p2() );
}


/**************************************************************************
* 函数名称： endTimeLineFinished
* 功能描述： endTimeLine的动画时间结束
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::endTimeLineFinished()
{
    //这个是发送的endTimeLine结束的信号
    //通知把游戏区域显示出来
    emit endTimeLineOverSignal() ;
}


/**************************************************************************
* 函数名称： clickOnOkButton
* 功能描述： 点击按钮的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::clickOnOkButton()
{
    beginEndTimeLine();     //开始endTimeLine效果

    emit nowLevelNumSignal( currentLevelNum ) ;
}
/**************************************************************************
* 函数名称： mousePressEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    int x = event->pos().x() ;
    int y = event->pos().y() ;
    int levelNum = getLevelNumbyNowPoint( QPoint(x,y) ) ;
    //DEBUGP( levelNum ) ;
    //如果用户选择一个可知关卡
    if( levelNum != NOT_SUCH_LEVEL )
    {
        //如果不是选择当前已经选择的关卡
        if(  levelNum != currentLevelNum )
        {
            currentLevelNum = levelNum ;
            //把对勾的Item坐标设置到当前的单击的位置，表示选择该关卡
            chooseItem->setPos( pointList.at( levelNum -1 ) ) ;
        }
    }
}



/**************************************************************************
* 函数名称： mouseReleaseEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSelectLevelItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "GameMovBackGrouItem : mouseReleaseEvent " ) ;
    //QGraphicsItem::mouseReleaseEvent( event ) ;
}
