#ifndef GAMESWIMFISHITEM_H
#define GAMESWIMFISHITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QTimer>


#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个是设置的鱼游动的更新时间间隔,单位为毫秒
#define    FISHSWIM_TIME       45


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这个是定义的五种鱼的类型。
enum GameFishType { FirstLeft , FirstRight , SecondLeft ,
                    SecondRight, ThirdLeft } ;

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个是游动的鱼的类，作为动态珊瑚背景的子Item加入
*/
class GameSwimFishItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    GameSwimFishItem(const QString &imageName,GameFishType fishType,
                     int xCoord , QGraphicsItem *parent=0);
    ~GameSwimFishItem();


    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;
private:
    /*
    每条鱼的不同状态的图片，因为每个图片总共是10条鱼，这里对应定义为10中不同状态
    */
    enum FishState { FishOne = 0 , FishTwo ,FishThree ,FishFour,
                 FishFive,FishSix,FishSeven,FishEight,FishNine,
                 FishTen } ;

    GameFishType myFishType ;    //这个是用来承载鱼类型的变量
    int myX_Coord ;              //这个是用来承载每条鱼初始x轴的值
    QString myImageName ;        //用来承载构造函数的imageName参数的
    QPixmap fishPixmap ;         //图片
    int perWidth ;               //这个是记录图片的宽与高的两个变量
    int perHeight ;              //注意这里记录的是一个状态的图片的宽与高，不是整张大图的宽与高
    //这个值是从配置文件中读出的
    QPoint firstPos ;           //这个表示fish图标的初始坐标值

    /*
    这个是通过每条鱼的不同的状态，从这fishPixmap一整张大图中
    得到相应的状态的图片的函数
    */
    inline QPixmap getFishStatePixmap( FishState state ) ;
    //根据鱼的种类和配置文件中读取的初始坐标来确定鱼的初始位置坐标
    QPoint getFirstPosByFishType( GameFishType fishtype,const QPoint &posFormFile ) ;

    QTimer *timer ;             //计数器用于更新鱼的位置

    int count ;                //这个是用于计数的计数器，默认为0
    void swimmingAdanceLittle( );   //这个函数控制小鱼向前游动一点

private slots:
    void timeoutSlot( ) ;        //timeout()信号的槽函数

};

#endif // GAMESWIMFISHITEM_H
