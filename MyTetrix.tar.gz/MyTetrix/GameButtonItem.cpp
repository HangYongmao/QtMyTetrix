#include "GameButtonItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameButtonItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameButtonItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameButtonItem::GameButtonItem(const QString &imageName, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myImageName(imageName)
    ,isPressed( false )
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    //设置该Item接收鼠标悬浮事件
    this->setAcceptHoverEvents ( true ) ;
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );
}



/***********************************************************************
* 函数名称： ~GameButtonItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameButtonItem::~GameButtonItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::setGameScene(GameGraphicsScene *gameScene, const NameAndImageHash
                                  &nameImagehash, const NameAndPointHash &namePointHash)
{
    QImage *image ;
    m_Scene = gameScene ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        buttonPixmap = QPixmap::fromImage( *image ) ;
        //一张大图包括5个小图，所以计算宽度时要除以5
        pixWidth = buttonPixmap.width() / 5  ;
        pixHeight = buttonPixmap.height() ;
        //默认的情况下是正常显示
        this->setPixmap( getButtonStatePixmap( Normal ) );
        //因为不是所有的Button都在同一层，所以不能在这里Z轴值

        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        if( namePointHash.contains( myImageName ) )
        {
            this->setPos( namePointHash.value( myImageName ) );
        }
        m_Scene->addItem( this );
    }

}


/**************************************************************************
* 函数名称： initPosAndImage
* 功能描述： 这个是做为子Item添加到父Item中
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::initPosAndImage(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    QImage *image ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        buttonPixmap = QPixmap::fromImage( *image ) ;
        //一张大图包括5个小图，所以计算宽度时要除以5
        pixWidth = buttonPixmap.width() / 5  ;
        pixHeight = buttonPixmap.height() ;
        //默认的情况下是正常显示
        this->setPixmap( getButtonStatePixmap( Normal ) );
        //因为不是所有的Button都在同一层，所以不能在这里Z轴值

        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        if( namePointHash.contains( myImageName ) )
        {
            this->setPos( namePointHash.value( myImageName ) );
        }
    }

}
/***********************************************************************
* 函数名称： getButtonStatePixmap()
* 功能描述： 这个是通过Button的不同的状态，从这buttonPixmap一整张大图中
*          得到相应的状态的图片的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
inline QPixmap GameButtonItem::getButtonStatePixmap(ButtonState state)
{
    Q_ASSERT( !buttonPixmap.isNull() ) ;
    return buttonPixmap.copy( state*pixWidth,0,pixWidth,pixHeight );
}


/**************************************************************************
* 函数名称： hoverEnterEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：注意这里是通过名字来限定那5个Button来发送信号
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    //DEBUGP( "hoverEnterEvent" ) ;
    Q_UNUSED( event ) ;
    this->setPixmap( getButtonStatePixmap( Actived ) );
    //通过名字来限定这5个Button，其他则不会发送这个信号
    if( myImageName == MODEWIN_START || myImageName == MODEWIN_INSTRUCTION ||
        myImageName == MODEWIN_OPTION || myImageName == MODEWIN_HIGHSCORE ||
        myImageName == MODEWIN_EXIT )
    {
        //DEBUGP( "hoverEnterEvent" ) ;
        emit mouseOnMe() ;   //发送信号
    }
    QGraphicsItem::hoverEnterEvent( event ) ;
}

/**************************************************************************
* 函数名称： hoverLeaveEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "hoverLeaveEvent" ) ;
    this->setPixmap( getButtonStatePixmap( Normal ) );

    QGraphicsItem::hoverLeaveEvent( event ) ;
}

/**************************************************************************
* 函数名称： mousePressEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "mousePressEvent" ) ;
    this->setPixmap( getButtonStatePixmap( Pressed ) );
    isPressed = true ;                //表示鼠标被按下

    //QGraphicsItem::mousePressEvent( event ) ;
}

/**************************************************************************
* 函数名称： mouseReleaseEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameButtonItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "mouseReleaseEvent" ) ;
    this->setPixmap( getButtonStatePixmap( Normal ) );
    if( isPressed )
    {
        isPressed = false ;
        //所有的按钮都会放送点击信号
        emit buttonClick();
    }
    //QGraphicsItem::mouseReleaseEvent( event ) ;
}
