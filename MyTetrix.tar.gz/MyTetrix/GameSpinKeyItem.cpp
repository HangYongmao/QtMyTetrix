#include "GameSpinKeyItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameSpinKeyItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameSpinKeyItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：注意这个类的构造函数的参数的意思：
*       imageName表示图片的名字，
*       volume表示初始化是音量的大小，默认为0，即没有声音
*       type表示的是类型，表示的是音乐的音量还是音效音量，默认是true，表示音乐音量
*       音效的spin的key图标的位置的初始值，在音乐spin的key的图标的位置的正下方
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameSpinKeyItem::GameSpinKeyItem(const QString &imageName, int volume, bool type, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent)
    ,myVolume(volume),myType(type)
    ,myImageName(imageName)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );
    //设置这个item可以移动
    //QGraphicsItem::ItemSendsGeometryChanges加入这个才可以在itemChange函数中得到坐标变化的
    this->setFlags( QGraphicsItem::ItemIsMovable |
                    QGraphicsItem::ItemSendsGeometryChanges );
}



/***********************************************************************
* 函数名称： ~GameSpinKeyItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameSpinKeyItem::~GameSpinKeyItem()
{

}

/**************************************************************************
* 函数名称： initPosAndImage
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameSpinKeyItem::initPosAndImage(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{

    QImage *image ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        keyPixmap = QPixmap::fromImage( *image ) ;

        this->setPixmap( keyPixmap );
        //这个Item不是要放到Scene中去的，而是作为子控件放进去的
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        //这个初始坐标，不是在Scene中的坐标，而是在父Item中的坐标
        if( namePointHash.contains( myImageName ) )
        {
            firstPos = namePointHash.value( myImageName ) ;
            /*
            音效的spin的key图标的位置的初始值，在音乐spin的key的图标的位置的正下方
            */
            if( !myType )
            {
                firstPos.setY( firstPos.y() + 60 );
            }
        }

        QPoint nowPoint = getNowPointByVolume( myVolume ) ;
        this->setPos( nowPoint );
    }
}

/***********************************************************************
* 函数名称： getNowPointByVolume()
* 功能描述： 根据音量的值，计算出spin图标坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 因为音量的值的变化范围是0到100，而图片在轨道上移动的范围是0到TRACKLENGTH，
*          所以要吧音量的值，转换为在图片在轨道上的偏移，只有x轴坐标改变，y轴坐标没有改变
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
inline QPoint GameSpinKeyItem::getNowPointByVolume(int volume)
{
    //转换为浮点型进行计算，结果转换为整形，这样的结果准确些
    int xOffset = (qreal)( volume * TRACKLENGTH ) / (qreal)100 ;
    //偏移只是在配置文件中所指定的初始值上进行偏移
    return QPoint( firstPos.x() + xOffset , firstPos.y() ) ;
}


/***********************************************************************
* 函数名称： getVolumeByNowPoint()
* 功能描述： 根据当前坐标的值，计算出对应音量的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
inline int GameSpinKeyItem::getVolumeByNowPoint(QPoint nowPoint)
{
    //因为y轴坐标不变，所以不考虑y轴的值
    int xOffset = nowPoint.x() - firstPos.x() ;
    return (int)( (qreal)(100*xOffset) / (qreal) TRACKLENGTH ) ;
}

/***********************************************************************
* 函数名称： getNowVolume()
* 功能描述： 这个是对外留出的接口，用于得到当前坐标转换为声音的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
int GameSpinKeyItem::getNowVolume()
{
    int x = this->pos().x() ;
    int y = this->pos().y() ;
    return getVolumeByNowPoint( QPoint(x,y) ) ;
}
/***********************************************************************
* 函数名称： itemChange()
* 功能描述： itemChange虚保护函数，在这里处理item的坐标改变
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过从配置文件读取的初始坐标值与轨道的长度，把其限定在一条直线上
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
QVariant GameSpinKeyItem::itemChange(GraphicsItemChange change, const QVariant &value)
{
    if (change == ItemPositionHasChanged && this->scene() )
    {
        int x = this->pos().x() ;
        int y = this->pos().y() ;
        //如果超过左边的界限
        if( x < firstPos.x() )
        {
            x = firstPos.x() ;
        }
        //如果超过右边的界限
        if( x > (firstPos.x() + TRACKLENGTH) )
        {
            x = (firstPos.x() + TRACKLENGTH) ;
        }
        //不允许上下移动
        if( y != firstPos.y() )
        {
            y = firstPos.y() ;
        }
        this->setPos( x,y );
    }
    return QGraphicsItem::itemChange(change, value);
}
