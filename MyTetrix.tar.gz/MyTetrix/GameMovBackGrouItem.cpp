#include "GameMovBackGrouItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameMovBackGrouItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameMovBackGrouItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameMovBackGrouItem::GameMovBackGrouItem(const QString &imageName, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myImageName(imageName)

{
    //用当前时间的秒数进行喂种，这样每次起来时，让小鱼在不同的位置出现！
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );
    /*
    可以通过下面这句话来接收鼠标点击事件，也可以通过重载
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;
    这两个函数
    */
    //this->setAcceptedMouseButtons( Qt::LeftButton );

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timeoutSlot()));
    timer->start( MOVEBACKUPDATE_TIME );


}



/***********************************************************************
* 函数名称： ~GameMovBackGrouItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameMovBackGrouItem::~GameMovBackGrouItem()
{
    /*第4层的Item*/
    delete speedNum ;
    delete rowNum ;
    delete scoreNum ;
    delete levelItem ;
    delete areaItem ;

    /*第5层的Item*/
    delete foreGroundItem ;
    delete gameOverItem ;
    delete gamePauseItem ;
}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景，这里由于显示时铺满整个场景，故不要初始坐标，所以只要啦两个参数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::setGameScene(GameGraphicsScene *gameScene,
                                       const NameAndImageHash &nameImagehash,
                                       const NameAndPointHash &namePointHash)
{
    QImage *movBackImage ;
    m_Scene = gameScene ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        movBackImage = nameImagehash.value( myImageName ) ;
        movBackPixmap = QPixmap::fromImage( *movBackImage ) ;

        //一张大图包括4个背景图，所以计算宽度时要除以4
        pixWidth = movBackPixmap.width() / 4  ;
        pixHeight = movBackPixmap.height() ;

        //默认显示的时候是显示的第一张图片
        this->setPixmap( getMoveBackPixmap( First ) );
        nowState = First ;       //记录当前图片的状态的

        m_Scene->addItem( this ) ;
        //添加5条游动的小鱼
        addSwimFishItem( nameImagehash,namePointHash ) ;
        //添加表示速度，行数，得分的数字的图片
        addAllGameNumItem(nameImagehash,namePointHash);
        //添加选择关卡的Item
        addGameSelectLevelItem(nameImagehash,namePointHash);
        //初始化用来承载图片容器的变量，之后给加载游戏区域时用
        m_nameImagehash = nameImagehash ;
        //在这里先给这个值进行初始化设置为空，否则可能到要返回游戏首页时出现段错误
        areaItem = NULL ;
        //添加前景图片的item
        addGameForeGroundItem( nameImagehash,namePointHash ) ;
        //添加游戏结束对话框的item
        addGameGameOverItem( nameImagehash,namePointHash ) ;
        //添加游戏暂停对话框的item
        addGameGamePauseItem(nameImagehash,namePointHash ) ;
    }

}


/***********************************************************************
* 函数名称： removeFourthAndFifthItemFun()
* 功能描述： 这个是删除第四层与第五层所有Item的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::removeFourthAndFifthItemFun()
{

    //删除第4层的Item
    if( speedNum != NULL )
    {
        m_Scene->removeItem( speedNum );
        speedNum->deleteLater();
        speedNum = NULL ;
    }

    if( rowNum != NULL )
    {
        m_Scene->removeItem( rowNum );
        rowNum->deleteLater();
        rowNum = NULL ;
    }

    if( scoreNum != NULL )
    {
        m_Scene->removeItem( scoreNum );
        scoreNum->deleteLater();
        scoreNum = NULL ;
    }

    if( levelItem != NULL )
    {
        m_Scene->removeItem( levelItem );
        levelItem->deleteLater();
        levelItem = NULL ;
    }
    //DEBUGP( "555removeFourthAndFifthItemFun" ) ;
    //在删除游戏区域之前，要先删除下一块的Item
    if( areaItem != NULL )
    {
        //DEBUGP( "111removeNextPieceItem" ) ;
        areaItem->removeNextPieceItem();
        //DEBUGP( "222removeNextPieceItem" ) ;
        m_Scene->removeItem( areaItem );
        //DEBUGP( "333removeNextPieceItem" ) ;
        areaItem->deleteLater();
        //DEBUGP( "444removeNextPieceItem" ) ;
        areaItem = NULL ;
    }

    //DEBUGP( "666removeFourthAndFifthItemFun" ) ;
    //删除第5层的Item
    if( foreGroundItem != NULL )
    {
        m_Scene->removeItem( foreGroundItem );
        foreGroundItem->deleteLater();
        foreGroundItem = NULL ;
    }
    if( gameOverItem != NULL )
    {
        m_Scene->removeItem( gameOverItem );
        gameOverItem->deleteLater();
        gameOverItem = NULL ;
    }

    if( gamePauseItem != NULL )
    {
        m_Scene->removeItem( gamePauseItem );
        gamePauseItem->deleteLater();
        gamePauseItem = NULL ;
    }

}
/***********************************************************************
* 函数名称： getMoveBackPixmap()
* 功能描述： 根据动态背景的状态得到这个状态下要显示的图片
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
inline QPixmap GameMovBackGrouItem::getMoveBackPixmap(MoveBackState state)
{
    Q_ASSERT( !movBackPixmap.isNull() ) ;
    return movBackPixmap.copy( state*pixWidth,0,pixWidth,pixHeight );
}


/***********************************************************************
* 函数名称： addSwimFishItem()
* 功能描述： 添加5条游动的小鱼
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addSwimFishItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    //从左边出发的第一条小鱼
    firstLeftFish = new GameSwimFishItem( MAINWIN_FISHLEFT,FirstLeft,getRandomXCoord(),this) ;
    firstLeftFish->initPosAndImage( nameImagehash,namePointHash );
    //从右边出发的第一条小鱼
    firstRightFish = new GameSwimFishItem( MAINWIN_FISHRIGHT,FirstRight,getRandomXCoord(),this);
    firstRightFish->initPosAndImage( nameImagehash,namePointHash );
    //从左边出发的第二条小鱼
    secondLeftFish = new GameSwimFishItem( MAINWIN_FISHLEFT,SecondLeft,getRandomXCoord(),this) ;
    secondLeftFish->initPosAndImage( nameImagehash,namePointHash );
    //从右边出发的第二条小鱼
    secondRightFish = new GameSwimFishItem( MAINWIN_FISHRIGHT,SecondRight,getRandomXCoord(),this) ;
    secondRightFish->initPosAndImage( nameImagehash,namePointHash );
    //从左边出发的第三条小鱼
    thirdLeftFish = new GameSwimFishItem( MAINWIN_FISHLEFT,ThirdLeft,getRandomXCoord(),this) ;
    thirdLeftFish->initPosAndImage( nameImagehash,namePointHash );
}


/***********************************************************************
* 函数名称： addGameSelectLevelItem()
* 功能描述： 添加选择关卡的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addGameSelectLevelItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    levelItem = new GameSelectLevelItem(MAINWIN_SELECTLEVEL);
    connect(levelItem,SIGNAL(nowLevelNumSignal(int)),this,SLOT(dealToDisNowLevel(int)));
    connect(levelItem,SIGNAL(endTimeLineOverSignal()),this,SLOT(dealToDisAreaItem()));
    levelItem->initPosAndImage( nameImagehash,namePointHash );
    m_Scene->addItem( levelItem );
    levelItem->setZValue(4.0);   //数字图片是作为第四层加到场景中去的
}
/***********************************************************************
* 函数名称： getRandomXCoord()
* 功能描述： 得到小鱼随机的x坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
int  GameMovBackGrouItem::getRandomXCoord()
{
    //得到0到800的随机数
    return  ( qrand() % 800 ) ;
}

/***********************************************************************
* 函数名称： addAllGameNumItem()
* 功能描述： 添加表示速度，行数，得分的数字的图片
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addAllGameNumItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    //表示速度的值的图片
    speedNum =new GameNumItem( BOX_NUMB,SpeedNum ) ;
    speedNum->initPosAndImage(nameImagehash,namePointHash);
    m_Scene->addItem( speedNum );
    speedNum->setZValue(4.0);   //数字图片是作为第四层加到场景中去的
    speedNum->setNumPixmap( "01" );

    //表示行数的值的图片
    rowNum =new GameNumItem( BOX_NUMB,RowNum ) ;
    rowNum->initPosAndImage(nameImagehash,namePointHash);
    m_Scene->addItem( rowNum );
    rowNum->setZValue(4.0);   //数字图片是作为第四层加到场景中去的
    rowNum->setNumPixmap( "00" );

    //表示行数的值的图片
    scoreNum =new GameNumItem( BOX_NUMB,ScoreNum ) ;
    scoreNum->initPosAndImage(nameImagehash,namePointHash);
    m_Scene->addItem( scoreNum );
    scoreNum->setZValue(4.0);   //数字图片是作为第四层加到场景中去的
    scoreNum->setNumPixmap( "000000" );

}

/***********************************************************************
* 函数名称： addGameAreaItem()
* 功能描述： 添加表示游戏区域的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addGameAreaItem(int levelNum, const NameAndImageHash &nameImagehash)
{
    areaItem = new GameAreaItem( levelNum ) ;
    //连接更新速度，总行数，已经分数的值的槽函数
    connect(areaItem,SIGNAL(updateSpeedNumSignal(int)),this,SLOT(updateSpeedNumSlot(int)));
    connect(areaItem,SIGNAL(updateNumRowsRemovedSignal(int)),
            this,SLOT(updateNumRowsRemovedSlot(int)));
    connect(areaItem,SIGNAL(updateScoreNumSignal(int)),this,SLOT(updateScoreNumSlot(int)));
    //连接游戏结束的信号与槽
    connect(areaItem,SIGNAL(gameOverSignal()),this,SLOT(gameOverSlot()));
    //连接从场景转发过来的重启信号
    connect(m_Scene,SIGNAL(restartButtonClickedSignal()),
            this,SLOT(gameRestartSlot())) ;
    //连接从场景中转发过来的游戏暂停信号
    connect(m_Scene,SIGNAL(pauseKeyDownSignal()),this,SLOT(pauseKeyDownSlot()));
    //连接从场景中转发过来的游戏被停用时的发送的信号
    connect(m_Scene,SIGNAL(gameDeactivateSignal()),this,SLOT(gameDeactivateSlot()));
    areaItem->setGameScene( m_Scene,nameImagehash );
    m_Scene->addItem( areaItem );
    //游戏区域的Item是作为第四层加到场景中去的
    areaItem->setZValue( 4.0 );
    //这个是设置坐标，因为这个不能从配置文件中读取，只能这么写死
    areaItem->setPos( 260,0 );
}


/***********************************************************************
* 函数名称： addGameForeGroundItem()
* 功能描述： 添加前景图片的item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addGameForeGroundItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    foreGroundItem = new GameForeGroundItem( MAINWIN_FOREGROUND ) ;
    foreGroundItem->setGameScene( m_Scene,nameImagehash,namePointHash);
    m_Scene->addItem( foreGroundItem );
    foreGroundItem->setZValue( 5.0 );        //前景作为第5层添加到场景中去
}


/***********************************************************************
* 函数名称： addGameGameOverItem()
* 功能描述： 添加游戏结束对话框的item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addGameGameOverItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    gameOverItem = new GameGameOverItem( MAINWIN_GAMEOVER ) ;
    gameOverItem->setGameScene( m_Scene,nameImagehash,namePointHash);
    m_Scene->addItem( gameOverItem );
    gameOverItem->setZValue( 5.0 );        //前景作为第5层添加到场景中去
    gameOverItem->hide();                  //默认是隐藏的，游戏结束时才显示出来
}

/***********************************************************************
* 函数名称： addGameGamePauseItem()
* 功能描述： 添加游戏暂停对话框的item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::addGameGamePauseItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    gamePauseItem = new GameGamePauseItem( MAINWIN_PAUSE ) ;
    gamePauseItem->setGameScene( m_Scene,nameImagehash,namePointHash);
    m_Scene->addItem( gamePauseItem );
    gamePauseItem->setZValue( 5.0 );        //前景作为第5层添加到场景中去
    gamePauseItem->hide();                  //默认是隐藏的，游戏暂停时才显示出来
}
/***********************************************************************
* 函数名称： timeoutSlot()
* 功能描述： timeout()信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::timeoutSlot()
{
    //根据当前状态，来轮流改变其图片的状态，达到动态显示的效果
    switch( nowState )
    {
    case First:
        this->setPixmap( getMoveBackPixmap( Second ) );
        nowState = Second ;
        break ;
    case Second:
        this->setPixmap( getMoveBackPixmap( Third ) );
        nowState = Third ;
        break ;
    case Third:
        this->setPixmap( getMoveBackPixmap( Fourth ) );
        nowState = Fourth ;
        break ;
    case Fourth:
        this->setPixmap( getMoveBackPixmap( First ) );
        nowState = First ;
        break ;
    default:
        DEBUGP( "MoveBackState error !" );
        break ;
    } 
}


/***********************************************************************
* 函数名称： dealToDisNowLevel()
* 功能描述： 当用户选择好关卡之后，显示在速度栏里面
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::dealToDisNowLevel(int levelNum)
{
    //记录当前的level数，这个是用于初始化TetrixBoard对象
    nowLevelNum = levelNum ;

    QString numString ;
    //两位数的话直接显示，一位数前面加个0在显示
    if( levelNum == 10)
    {
        numString.setNum( levelNum ) ;
    }
    else
    {
        numString = QString("0%1").arg(levelNum) ;
    }
    //设置当前的关卡数
    speedNum->setNumPixmap( numString );
}

/***********************************************************************
* 函数名称： dealToDisAreaItem()
* 功能描述： 这个是发送的endTimeLine结束的信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：这个是当按游戏关卡上的确定按钮后的向上的动画结束时的之后的槽函数
*         在这个时候才加载游戏区域
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void GameMovBackGrouItem::dealToDisAreaItem()
{
    //添加表示游戏区域的Item
    addGameAreaItem( nowLevelNum,m_nameImagehash );
}


/**************************************************************************
* 函数名称： updateSpeedNumSlot
* 功能描述： 这个是更新消除的速度的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::updateSpeedNumSlot(int speednum)
{
    //速度的值只能为1到10，10个数字
    QString numString ;
    if( speednum != 10 )
    {
        numString = QString("0%1").arg(speednum) ;
    }
    else
    {
        numString.setNum( speednum ) ;
    }
    speedNum->setNumPixmap( numString );
}

/**************************************************************************
* 函数名称： updateNumRowsRemovedSlot
* 功能描述： 这个是更新消除的总行数的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：保证其至少显示两个数字,比如7就用07显示，17就直接显示，以此类推
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::updateNumRowsRemovedSlot(int rownum)
{
    QString numString ;
    if( rownum < 10 )
    {
        numString = QString("0%1").arg(rownum) ;
    }
    else
    {
        numString.setNum( rownum ) ;
    }
    rowNum->setNumPixmap( numString );
}

/**************************************************************************
* 函数名称： updateScoreNumSlot
* 功能描述： 这个是更新消除的用户分数的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::updateScoreNumSlot(int scorenum )
{
    //分数是10的倍数，故不可能出现个位数的时候
    QString numString ;
    numString.setNum( scorenum ) ;
    int count = numString.count() ;
    //因为默认以6个数字显示，如果不够则在前面补0
    if( count < 6 )
    {
        //差几位就在前面补几个0
        for( int i =0 ; i< ( 6 - count ); i++)
        {
            numString = numString.insert(0,"0") ;
        }
    }
    scoreNum->setNumPixmap( numString );
}

/**************************************************************************
* 函数名称： gameOverSlot
* 功能描述： 这个是发送的游戏结束的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::gameOverSlot()
{
    //DEBUGP( "gameOverSlot" ) ;
    //因为默认是被隐藏啦的，在这里给显示出来
    gameOverItem->show();
}


/**************************************************************************
* 函数名称： gameRestartSlot
* 功能描述： 这个是游戏重新开始的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::gameRestartSlot()
{
    //DEBUGP( "111gameRestartSlot" )
    if( gameOverItem != NULL )
    {
        //DEBUGP( "222gameRestartSlot" )
        //把游戏结束的Item给隐藏起来重新开始游戏
        gameOverItem->hide();

    }

    if( areaItem != NULL )
    {
        //DEBUGP( "333gameRestartSlot" )
        areaItem->removeNextPieceItem();
        //在这里把游戏区域给移除场景中，因为要回到选择游戏关卡的位置
        m_Scene->removeItem( areaItem );

        areaItem->deleteLater();
        areaItem = NULL ;
    }

    if( levelItem != NULL )
    {
        //DEBUGP( "444gameRestartSlot" )
        //把游戏关卡选择的动画打开，重新选择游戏关卡
        levelItem->beginStartTimeLine();
    }

}


/**************************************************************************
* 函数名称： pauseKeyDownSlot
* 功能描述： 按下p键的暂停游戏的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::pauseKeyDownSlot()
{
    if( gamePauseItem != NULL )
    {
        bool visible = gamePauseItem->isVisible() ;
        //设置跟当前属性相反的显示属性
        //也就是说是隐藏则显示，当前是显示则隐藏
        gamePauseItem->setVisible( !visible );
    }
}


/**************************************************************************
* 函数名称： gameDeactivateSlot
* 功能描述： 这个是当游戏被停用时的发送的信号
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::gameDeactivateSlot()
{
    if( gamePauseItem != NULL )
    {
        bool visible = gamePauseItem->isVisible() ;
        //这个只需要让其暂停，不要让其解除暂停功能
        if( !visible )
        {
            gamePauseItem->setVisible( true );
        }

    }
}
/**************************************************************************
* 函数名称： mousePressEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "GameMovBackGrouItem : mousePressEvent " ) ;
    //QGraphicsItem::mousePressEvent( event ) ;
}

/**************************************************************************
* 函数名称： mouseReleaseEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameMovBackGrouItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
    //DEBUGP( "GameMovBackGrouItem : mouseReleaseEvent " ) ;
    //QGraphicsItem::mouseReleaseEvent( event ) ;
}

