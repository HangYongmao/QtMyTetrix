#include <QApplication>
#include <QTextCodec>
#include <QCursor>

#include "TetrixWidget.h"

int main( int argc, char **argv )
{

    QApplication a( argc, argv );

    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    //则更换图标
    QCursor myCursor( QPixmap( GLOBAL_CURSOR_IMAGE ) ) ;
    QApplication::setOverrideCursor( myCursor ) ;
    //这个是因为要使用Phonon这里要设置一个名字，可能是考虑到版权相关的问题吧，不然会有一个警告
    //并无其他实际意义
    a.setApplicationName("MyTetrix Game");

    TetrixWidget widget ;
    widget.show();

    return a.exec();
}

